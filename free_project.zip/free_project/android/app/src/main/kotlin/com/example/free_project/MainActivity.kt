package com.example.free_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
