import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:flutter_vibrate/flutter_vibrate.dart';
import 'package:free_project/location.dart';
import 'package:geolocator/geolocator.dart';
import 'package:page_transition/page_transition.dart';
import 'package:http/http.dart' as http;

import 'getLocation.dart';
import 'notify.dart';

class MyHomePage extends StatefulWidget {
  MyHomePage({required this.title}) : super();
  final String title;
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  BigPictureStyleInformation styleInform = BigPictureStyleInformation(
    DrawableResourceAndroidBitmap("fffg"),
    contentTitle: "Location - Sector 3, Chandigarh",
    htmlFormatContentTitle: true,
    largeIcon: DrawableResourceAndroidBitmap("app_icon"),
    htmlFormatContent: true,
  );

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    var androidInitialize = new AndroidInitializationSettings('firefighter');
    var iosInitialize = new IOSInitializationSettings();
    var initializeSettings = new InitializationSettings(
        android: androidInitialize, iOS: iosInitialize);
    _flutterLocalNotificationsPlugin.initialize(
      initializeSettings,
      onSelectNotification: notificationSelection,
    );
  }

  Future _showNotification() async {
    var androidDetails = new AndroidNotificationDetails(
      'channelId',
      'channelName',
      channelDescription: 'channel Description',
      importance: Importance.max,
      styleInformation: styleInform,
      color: Colors.red,
      autoCancel: true,
      enableVibration: true,
    );
    var iosDetails = new IOSNotificationDetails();
    var generalNotifications =
        new NotificationDetails(android: androidDetails, iOS: iosDetails);
    await _flutterLocalNotificationsPlugin.show(
        0, "Fire Alert!", "Rush Immediately!", generalNotifications,
        payload: "Location - Sector 3, Chandigarh");
  }

  Future notificationSelection(String? payload) async {
    await Navigator.push(
        context,
        PageTransition(
            child: Notify(
              payload: payload ?? "null",
            ),
            type: PageTransitionType.bottomToTop)
        // MaterialPageRoute(
        //   builder: (context) => Notify( payload: payload??"null",),
        // ),
        );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Padding(
        padding: const EdgeInsets.only(right: 20.0),
        child: GestureDetector(
          onTap: () async {
            Position position = await determinePosition();
            print(position);
          },
          child: Drawer(
            child: DrawerHeader(
              child: Container(
                child: Center(child: Text("Welcome to free!")),
              ),
            ),
          ),
        ),
      ),
      backgroundColor: Colors.red.shade100,
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 20),
            child: InkWell(
              child: Icon(Icons.notifications_active),
              onTap: () {
                _showNotification()
                    .then((value) => Vibrate.feedback(FeedbackType.warning));
              },
            ),
          )
        ],
        elevation: 5,
        centerTitle: true,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(40),
                bottomLeft: Radius.circular(40))),
      ),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Container(
          margin: EdgeInsets.all(15),
          // padding: EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Card(
                elevation: 5,
                child: TextFormField(
                  onFieldSubmitted: (text) => setState(() {
                    print(text);
                    update = text;
                  }),
                  initialValue: '  Texas',
                  decoration: InputDecoration(
                    labelText: 'Search Location',
                    hintText: "Enter a city",
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(
                      Icons.location_on,
                    ),
                  ),
                ),
              ),
              FutureBuilder<List<Images>>(
                future: fetchPhotos(http.Client()),
                builder: (context, snapshot) {
                  if (snapshot.hasError) print(snapshot.error);

                  return snapshot.hasData
                      ? PhotosList(photos: snapshot.data!)
                      : Center(child: CircularProgressIndicator());
                },
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          const number = '101'; //set the number here
          await FlutterPhoneDirectCaller.callNumber(number);
        },
        icon: Icon(
          Icons.local_hospital_outlined,
        ),
        elevation: 5,
        label: Text("SOS"),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}
