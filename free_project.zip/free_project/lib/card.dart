import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class ListCard extends StatefulWidget {
  final String title;
  final String url;
  final String whatsapp;
  final String phone;
  const ListCard({Key? key,required this.title,required this.url, required this.whatsapp, required this.phone}) : super(key: key);

  @override
  _ListCardState createState() => _ListCardState();
}

class _ListCardState extends State<ListCard> {

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.all(5),
        child: Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          elevation: 5,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius:BorderRadius.all(Radius.circular(5)),
                    color: Colors.red,
                  ),
                  child: ListTile(
                    leading: Image.asset("images/firefighter.png",scale: 12,),
                    title: Text(widget.title,style: TextStyle(color: Colors.white)),
                    subtitle: Text('We fight fire to protect you!',style: TextStyle(color: Colors.white),),
                  ),
                ),
              ),
              SizedBox(height: 15,),
              Image.network(
                widget.url,
                fit: BoxFit.fill,
                height: 150,
                width: 250,
                loadingBuilder: (BuildContext context, Widget child,
                    ImageChunkEvent? loadingProgress) {
                  if (loadingProgress == null) return child;
                  return Center(
                    child: CircularProgressIndicator(
                      value: loadingProgress.expectedTotalBytes != null
                          ? loadingProgress.cumulativeBytesLoaded /
                          loadingProgress.expectedTotalBytes!
                          : null,
                    ),
                  );
                },
              ),
              SizedBox(height: 20,),
              ButtonTheme( // make buttons use the appropriate styles for cards
                child: ButtonBar(
                  alignment: MainAxisAlignment.end,
                  children: <Widget>[
                    FlatButton(
                      child: const Text('Whatsapp',style: TextStyle(color: Colors.green,),),
                      onPressed: () async {

                        var whatsapp ="+91"+widget.whatsapp;
                        var whatsappURlAndroid = "whatsapp://send?phone="+whatsapp+"&text=Hey! A Fire broke out in Sector 3, Chandigarh, Please Help!";
                        await launch(whatsappURlAndroid);

                      },
                      shape:
                      RoundedRectangleBorder(
                        // borderRadius: BorderRadius.circular(10.0),
                          side: BorderSide(color: Colors.green)
                      ),
                      splashColor: Colors.green,
                      autofocus: true,

                    ),
                    SizedBox(width: 1,),
                    FlatButton(
                      child: const Text('Call'),
                      color: Colors.red,
                      onPressed: () {
                        launch("tel://"+widget.phone);
                      }
                    ),
                    SizedBox(width: 1,),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
