import 'dart:async';
import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'card.dart';

String update = '';

Future<List<Images>> fetchPhotos(http.Client client) async {
  final response = await client.get(Uri.parse(
      "https://serpapi.com/search.json?engine=google_maps&q=firestation"
      "&ll=@40.7455096,-74.0083012,15.1z&type=search&"
      "api_key=0306c7674ebe92827c6555c3460d8ea6a85f4881f7aa014560bfe19a2ff738c0"));
  // print(response.body);

  // Use the compute function to run parsePhotos in a separate isolate.
  return compute(parsePhotos, response.body);
}

// A function that converts a response body into a List<Photo>.
List<Images> parsePhotos(String responseBody) {
  List<Images> list;
  var data = json.decode(responseBody);
  var rest = data["local_results"] as List;
  print(rest);
  list = rest.map<Images>((json) => Images.fromJson(json)).toList();

  print("List Size: ${list.length}");
  return list;
}

class Images {
  final String title;
  final String thumbnail;

  Images({
    required this.title,
    required this.thumbnail,
  });

  factory Images.fromJson(Map<String, dynamic> json) {
    return Images(
      thumbnail: json['thumbnail'] as String,
      title: json['title'] as String,
    );
  }
}

class PhotosList extends StatelessWidget {
  final List<Images> photos;

  PhotosList({Key? key, required this.photos}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ListView.builder(
          // scrollDirection: Axis.horizontal,
          // shrinkWrap: true,
          physics: ScrollPhysics(),
          itemCount: photos.length,
          itemBuilder: (context, index) {
            return Container(
              child: ListCard(
                title: photos[index].title.isEmpty
                    ? "Fire Station"
                    : photos[index].title,
                url: photos[index].thumbnail.isEmpty
                    ? "https://www.ssf.net/home/showpublishedimage/3118/636396008145370000"
                    : photos[index].thumbnail,
                phone: "8133811679",
                whatsapp: "8133811679",
              ),
            );
          }),
    );
  }
}
